The user should follow my instructions below:
Step 1: The user needs to install the npm package and nodeJS on his or her computer. You can see the instructions at https://nodejs.org/en/download/.
Step 2: The user should pull my code from my GitHub (I put it in reference).
Step 3: The user should install some extensions in VS Code, such as Babel JavaScript, JS6 Code Snippets, and the REST client.
Step 4: The user opens his or her terminal (ctrl + shift + ` ) and goes to the root path. Then they run the command npm install -i.
Step 5: The user should split the terminal because my project runs on two different ports. Then the user goes to the server and runs two commands on each terminal: npm run auth and npm run dev. 
